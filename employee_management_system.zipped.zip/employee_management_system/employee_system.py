import mysql.connector
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Chini@825",
    database="employee_db"
)
cursor=db.cursor()
while True:
    print("/n1. Add Employee")
    print("2. View Employee")
    print("3. delete Employee")
    print("4. Exit:")

    choice = input("Enter Choice: ")
    if choice == "1":
        name =  input("Enter name: ")
        age = int(input("Enter age: "))
        dept = input("Enter department: ")
        cursor.execute("INSERT INTO employees_1 (name, age, dept) VALUES (%s, %s, %s)", (name, age, dept))
        db.commit()
        print("Employ Added!")

    elif choice == "2":
        cursor.execute("SELECT * FROM employees_1")
        for row in cursor.fetchall():
            print(row)

    elif choice == "3":
        emp_id = input("Enter ID to delete")
        cursor.execute("DELETE FROM employees_1 WHERE id = %s", (emp_id,))
        db.commit()
        print("Employ Deleted")

    elif choice == "4":
        print("Exiting program...")
        break
    else:
        print("Invalid choice")