# Employee Management System (python + MySQL)
This project is a menu-driven python application that connects to a MYSQL database to manage employee data.
## Features 
-Add new Employee
-View all Employees
-Delete employee
-Exit menu safely

## Technlogies used 
-Python
-MYSQL
-mysql.connector
## How to Run:
1. install MYSQL and create a database named "company".
2. insatll the MYSQL connector library:
pip install mysql.connector-python
3. Run the script:
python employee_management.py

## Example menu 
!. Add Employee
2. View Employee
3. Delete Employee
4. Exit